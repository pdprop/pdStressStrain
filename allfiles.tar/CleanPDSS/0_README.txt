
# If you have downloaded all the files you can compile the
# Fortran programs   using the command:
#               ./Allcompile

# For information on how to use the programs please see the
# web page:
#    http://fde.uwaterloo.ca/Fde/CT/pdStressStrain.html

# The process:
#    1.  edit your strain input history.  e.g.:strains1.txt
#    2.  Assuming you are just using 10 layers:
#    3.  Run the script:
#                  ./runLayers  strains1.txt
#    4.  Then use the report scripts
#         examples:
#                     ./reportEvent 2062.19

#                     ./report2events  2500 2568.63
#
# Its probably informative to read the scripts before you 
# use them.

# Other Linux software needed(or helpful):
#      gnuplot, htmldoc,  xv, gfortran(requires gcc probably)

# PS:  good fatigue data would be nice too.

# have fun,
# A.

 
